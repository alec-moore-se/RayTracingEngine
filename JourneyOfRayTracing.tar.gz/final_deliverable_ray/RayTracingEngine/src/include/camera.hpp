#pragma once

#include "color.hpp"
#include "commons.hpp"
#include "hittable.hpp"
#include "material.hpp"
#include "vec3.hpp"
#include <cstdint>
#include <sstream>
#include <string>
#include <thread>

class camera {
  int image_height;
  point3 center;
  point3 pixel00_loc;
  vec3 pixel_delta_u, pixel_delta_v;
  double pixel_samples_scale;
  vec3 u, v, w;
  vec3 defocus_disk_u, defocus_disk_v;

  void initialize() {
    image_height = int(image_width / aspect_ratio);
    image_height = (image_height < 1) ? 1 : image_height;

    pixel_samples_scale = 1.0 / samples_per_pixel;
    center = lookfrom;

    // Determine viewport dimensions.
    auto theta = deg_to_rad(vfov);
    auto h = std::tan(theta / 2);
    auto viewport_height = 2.0 * h * focus_dist;
    auto viewport_width =
        viewport_height * (double(image_width) / image_height);

    w = unit_vector(lookfrom - lookat);
    u = unit_vector(cross_product(vup, w));
    v = cross_product(w, u);
    // Calculate the vectors across the horizontal and down the vertical
    // viewport edges.
    auto viewport_u = viewport_width * u;
    auto viewport_v = viewport_height * -v;

    // Calculate the horizontal and vertical delta vectors from pixel to pixel.
    pixel_delta_u = viewport_u / image_width;
    pixel_delta_v = viewport_v / image_height;

    // Calculate the location of the upper left pixel.
    auto viewport_upper_left =
        center - (focus_dist * w) - viewport_u / 2 - viewport_v / 2;
    pixel00_loc = viewport_upper_left + 0.5 * (pixel_delta_u + pixel_delta_v);

    auto defocus_rad = focus_dist * std::tan(deg_to_rad(defocus_angle / 2));
    defocus_disk_u = u * defocus_rad;
    defocus_disk_v = v * defocus_rad;
  }

  color ray_color(const ray &r, int depth, const hittable &world,
                  const hittable &lights) {
    if (depth <= 0)
      return color(0, 0, 0);

    hit_rec rec;
    scatter_record srec;

    if (!world.hit(r, interval(0.001, infinity), rec))
      return background_color;

    color emission_color = rec.mat->emitted(r, rec);

    if (!rec.mat->scatter(r, rec, srec))
      return emission_color;
    if (srec.skip_pdf)
      return srec.attenuation *
             ray_color(srec.skip_pdf_ray, depth - 1, world, lights);

    //    auto light_pdf = make_shared<hittable_pdf>(lights, rec.p);
    //    Mixture_PDF mixture_pdf(light_pdf, srec.pdf_ptr);
    //    auto scattered = ray(rec.p, mixture_pdf.generate(), r.time());
    //    auto pdf = mixture_pdf.value(scattered.direction());
    auto light_pdf = hittable_pdf(lights, rec.p);
    bool sampler = random_double() < 0.5;
    double pdf1, pdf2;
    vec3 scattered_dir;
    if (sampler) {
      scattered_dir = light_pdf.generate();
      pdf1 = light_pdf.value(scattered_dir);
      pdf2 = srec.pdf_ptr->value(scattered_dir);
    } else {
      scattered_dir = srec.pdf_ptr->generate();
      pdf1 = light_pdf.value(scattered_dir);
      pdf2 = srec.pdf_ptr->value(scattered_dir);
    }

    auto pdf = 0.5 * pdf1 + 0.5 * pdf2;
    auto scattered = ray(rec.p, scattered_dir, r.time());

    // div by zero or close to zero guard
    if (std::fabs(pdf) < epsilon_dou)
      return background_color;

    double scattering_pdf = rec.mat->scattering_pdf(r, rec, scattered);

    color sample_color = ray_color(scattered, depth - 1, world, lights);

    double pwr_heuristic =
        (sampler)
            ? (std::pow(pdf1, 2) / (std::pow(pdf1, 2) + std::pow(pdf2, 2)))
            : (std::pow(pdf2, 2) / (std::pow(pdf1, 2) + std::pow(pdf2, 2)));

    color scatter_color =
        (srec.attenuation * scattering_pdf * sample_color * pwr_heuristic) /
        pdf;
    scatter_color = clamp(scatter_color, 20);

    return emission_color + scatter_color;
  }

  ray get_ray(int i, int j) const {
    auto offset = sample_square();

    auto pixel_sample = pixel00_loc + ((i + offset.x()) * pixel_delta_u) +
                        ((j + offset.y()) * pixel_delta_v);
    auto ray_origin = (defocus_angle <= 0) ? center : defocus_disk_sample();
    auto ray_direction = pixel_sample - ray_origin;
    auto ray_time = random_double();

    return ray(ray_origin, ray_direction, ray_time);
  }

  vec3 sample_square() const {
    return vec3(random_double() - 0.5, random_double() - 0.5, 0);
  }

  point3 defocus_disk_sample() const {
    auto p = random_unit_disk();
    return center + (p[0] * defocus_disk_u) + (p[1] * defocus_disk_v);
  }

public:
  double aspect_ratio = 1.0; // Ratio of image width over height
  int image_width = 100;     // Rendered image width in pixel count
  double samples_per_pixel = 10;
  int max_depth = 10;
  float vfov = 90;
  point3 lookfrom = point3(0, 0, 0);
  point3 lookat = point3(0, 0, -1);
  vec3 vup = vec3(0, 1, 0);

  double defocus_angle = 0;
  double focus_dist = 10;
  color background_color;

  void render(const hittable &world, const hittable &lights) {
    initialize();

    std::cout << "P3\n" << image_width << ' ' << image_height << "\n255\n";

    for (int j = 0; j < image_height; j++) {
      std::clog << "\rScanlines remaining: " << (image_height - j) << ' '
                << std::flush;
      for (int i = 0; i < image_width; i++) {
        color pixel_color = color(0, 0, 0);
        for (int s = 0; s < samples_per_pixel; s++) {
          ray r = get_ray(i, j);
          pixel_color += ray_color(r, max_depth, world, lights);
        }
        write_color(std::cout, pixel_samples_scale * pixel_color);
      }
    }

    std::clog << "\rDone.                 \n";
  }
  void threaded_render(const hittable &world, const hittable &lights) {
    initialize();

    std::cout << "P3\n" << image_width << ' ' << image_height << "\n255\n";

    const int num_threads = std::thread::hardware_concurrency();
    int rows_per_thread = image_height / num_threads;

    std::vector<std::thread> threads;
    std::vector<std::stringstream> partial_results(num_threads);

    for (int t = 0; t < num_threads; ++t) {
      int y_start = t * rows_per_thread;
      int y_end =
          (t == num_threads - 1) ? image_height : y_start + rows_per_thread;

      threads.emplace_back([&, t, y_start, y_end]() {
        partial_results[t] = threader(y_start, y_end, world, lights);
      });
    }

    for (auto &t : threads)
      t.join();

    for (auto &ss : partial_results)
      std::cout << ss.str();
  }

  std::stringstream threader(int y_start, int y_end, const hittable &world,
                             const hittable &lights) {

    std::stringstream ss;

    for (int j = y_start; j < y_end; j++) {
      std::clog << "\rScanlines remaining for Thread(" << y_start << '-'
                << y_end << "): " << y_end - j << ' ' << std::flush;
      for (int i = 0; i < image_width; i++) {
        color pixel_color(0, 0, 0);

        for (int s = 0; s < samples_per_pixel; s++) {

          ray r = get_ray(i, j);
          pixel_color += ray_color(r, max_depth, world, lights);
        }
        write_color(ss, pixel_samples_scale * pixel_color);
      }
    }

    std::clog << "\rDone." << y_start << "-" << y_end
              << "                                       \n";

    return ss;
  }
};
